<?php
echo 'rejestracja przeszła pomyslnie';
?>

<!DOCTYPE html>
<html>

<head>
    <title>rejestracja</title>

</head>

<body><br><br>
<a href="../logowanie.php"><button>powrót do menu</button></a></body>
</html>

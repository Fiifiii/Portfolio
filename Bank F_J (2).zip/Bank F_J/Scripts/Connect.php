<?php

$host = "localhost";
$uzytkownik = "v55582550_julek";
$haslo = "Hr4!6_h7P2MPTo";
$baza_danych = "v55582550_julek";

$conn = new mysqli($host, $uzytkownik, $haslo, $baza_danych);


